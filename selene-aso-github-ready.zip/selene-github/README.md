# Selene ASO rank track

A lightweight local ASO keyword tracking dashboard for **Apple App Store** and **Google Play**. The dashboard runs in your browser; a small Python server retrieves available keyword search-result listings on demand. No paid ASO API, account, hosted backend, or database is required.

> **Data accuracy:** Automatically detected positions are **provisional positions in returned search lists**, **not independently verified organic App Store / Google Play ranks**. They may differ from the consumer storefront. Missing results mean *not detected in the returned list*, **not** proof that an app is organically unranked.

## Features

- Track multiple apps and keywords by store, country, and language.
- Retrieve on-demand search-list positions for supported Apple and Google Play searches.
- Show numeric detected positions, source metadata, and keyword buckets.
- View separate **Detected Positions** and **Recorded Organic** modes.
- Inspect current/previous observations, ranking movement, summary metrics, and charts when data is available.
- Search, sort, and filter the keyword table.
- Import historical ranking snapshots from CSV and export current positions, history, or bucket totals.
- Store workspace information locally in your browser. No automatic background tracking.

## Files

| File | Purpose |
| --- | --- |
| `selene-aso-rank-track.html` | Dashboard user interface and CSV/local-storage logic |
| `rank_server.py` | Local Python HTTP server and on-demand store search requests |
| `requirements.txt` | Python dependency (`google-play-scraper`) |
| `start_windows.bat` | Windows launcher that installs dependencies and starts the local server |
| `README.md` | Setup, usage, and technical documentation |
| `.gitignore` | Prevents Python caches and local environment files from being committed |

## Quick start: Windows

1. Install **Python 3** from https://www.python.org/downloads/ and ensure `python` works in Command Prompt.
2. Download this repository (green **Code** button -> **Download ZIP**) and **extract the complete ZIP** into one folder.
3. Open the extracted folder and double-click **`start_windows.bat`**.
4. Allow dependency installation the first time (internet connection required).
5. Open **http://127.0.0.1:8765/selene-aso-rank-track.html** if it does not open automatically.
6. Keep the Command Prompt window open while using the app; close it or press **Ctrl+C** to stop the Python server.

**Important:** Run the launcher from the extracted folder, not the ZIP preview. It expects `requirements.txt`, `rank_server.py`, and `selene-aso-rank-track.html` in the same directory. If port `8765` is already occupied, close the older Python server first.

### Manual start (Windows, macOS, Linux)

From the folder containing the project:

```bash
python -m pip install -r requirements.txt
python rank_server.py
```

Then visit **http://127.0.0.1:8765/selene-aso-rank-track.html**. On some macOS/Linux systems the Python command is `python3` rather than `python`.

## Daily workflow

1. Paste a Google Play or Apple App Store app URL and click **Identify app**.
2. Choose the target **country** and **language**.
3. Add keywords (one per line) and click **Add Keywords**.
4. Click **Check Search Results (Free Local Python)**.
5. Switch to **Detected Positions** to see detected numeric search-list positions and source details. A number is **not a certified organic rank**.
6. Use **Open search** to inspect storefront results yourself. If you personally verify an organic position, record it in **Recorded Organic** mode using the appropriate row action.
7. Export rankings or history to CSV regularly. Browser storage is not synced to GitHub.

### Keyword buckets

Buckets are mutually exclusive:

- **Unranked** — no available detected/recorded numeric position **in the selected view**; this does not prove the storefront rank is absent.
- **Position 1**
- **Position 2 to 3**
- **Position 4 to 10**
- **Position 11 to 20**
- **Position > 20**
- **Total** — all tracked keyword rows included by the selected filters.

## How keyword detection works

```text
App URL + app ID + keywords + country/language
                      |
                      v
Browser dashboard -> POST /api/check -> local Python server
                                          |
                         +----------------+----------------+
                         |                                 |
                    Apple App Store                   Google Play
                         |                                 |
                 Apple iTunes Search API        google-play-scraper library
                         |                                 |
                 returned trackId values        returned appId values
                         +----------------+----------------+
                                          |
                            exact app-ID/package-ID match
                                          |
                         detected position or no-match status
                                          |
                              dashboard + CSV export
```

**Apple App Store:** `rank_server.py` queries `https://itunes.apple.com/search` with the keyword, software entity, selected country, and a requested limit of 200. It compares each returned `trackId` to the numeric Apple app ID and reports the **1-based position in that API response**. The API ordering is **not equivalent to confirmed storefront organic keyword ranking**. The language selection is not passed through as a query parameter to this API.

**Google Play:** The Python code uses `google_play_scraper.search(keyword, lang=..., country=..., n_hits=100)` and compares each returned `appId` to the exact Google Play package ID. If an ID matches, it reports its **1-based index within the returned list**. The library may return fewer than 100 results, and the results can differ from those shown on the public Play storefront. If the app isn't in the returned list, the script also attempts a country-specific app-details lookup for diagnostics; that lookup **does not determine keyword rank**.

**API handling:** The local server listens only on `127.0.0.1:8765`. The dashboard requests `/api/check` when you click the check button. Requests are limited to 100 keywords per batch. Responses include `position`, `status`, `source`, `verified_organic: false`, and, where available, `results_scanned` and explanatory notes. The server does not run a scheduled/background monitor.

### Important ranking limitations

- Apple iTunes Search API positions are API result-list positions, not certified App Store organic positions.
- Google Play scraped-result positions are provisional and can differ by country, device, personalization, ads, and result layout.
- **Not detected** / **Not in API** / **Unranked** cannot establish that an app is organically unranked.
- The scraper and public APIs may fail, throttle requests, return incomplete lists, or change behavior without notice.
- Historical trend charts require real dated snapshots. The tool must not invent past results.
- For audited SEO/ASO reporting, independently verify ranks using an appropriate storefront or trusted provider.

## CSV import and export

Use **CSV template** in the dashboard. Historical imports expect the columns:

```csv
keyword,rank,date,store,country,app_id,app_name,language,source,verified
```

Required columns: `keyword`, `rank`, `date`, `store`, `country`, `app_id`. Dates use `YYYY-MM-DD`. `rank` is a positive integer or an unavailable marker. Optional metadata includes `app_name`, `language`, `source`, and `verified`.

The current-results export includes fields such as `export_date`, `keyword`, numeric `rank`, `store`, `country`, `app_id`, `source`, `category`, and `data_quality`. Preserve `source` and `data_quality` when distributing ranking reports so provisional positions are not mistaken for verified organic ranks.

## Data and privacy

The dashboard stores app details, keywords, detected positions, and historical observations in **browser local storage** for the current site origin. Data does **not** automatically sync across browsers, computers, or GitHub. Export a CSV backup before clearing browser storage or moving to a new URL/origin. App metadata and keyword searches are sent to Apple/Google endpoints on demand through the Python server. Do not commit exported client-specific ranking CSVs or credentials to a public repository.

## GitHub repository setup

1. On GitHub, create a repository called `selene-aso-rank-track`.
2. Choose **Private** for internal company use or **Public** if source code should be visible to everyone.
3. Open the repository and select **Add file -> Upload files**.
4. Upload the **individual extracted project files**, including `README.md` (do not upload only the ZIP).
5. Commit the files. GitHub automatically displays this README on the repository homepage.
6. To share the complete locally runnable tool, teammates can choose **Code -> Download ZIP**, extract it, and start `start_windows.bat`.

### GitHub Pages: optional dashboard preview only

GitHub Pages serves static files but **cannot run Python**. If you enable Pages, visitors can see the dashboard; **Check Search Results** will not work there because `/api/check` is supplied only by the local Python server. To publish a working multi-user online ranking checker, you would need to deploy the Python API separately with appropriate authentication, origin protection, provider compliance, and rate limits. This project intentionally does not include that deployment.

## Troubleshooting

| Problem | What to check |
| --- | --- |
| `requirements.txt` not found | Extract the entire ZIP; run the launcher inside the extracted folder. |
| Previous server is running | Close the prior Command Prompt or press Ctrl+C, then restart. |
| Browser says connection refused | Verify Python server is still running and listening on port 8765. |
| `Not detected` | The exact app ID was absent from the returned list; inspect the diagnostic note and `results_scanned` value. |
| `Unavailable` or error | Check your connection, dependency installation, and Python terminal output. |
| Dashboard looks outdated | Open `/selene-aso-rank-track.html` on localhost, close the old server, and refresh. |
| Rankings not shown on GitHub Pages | GitHub Pages does not execute the Python API. Run locally. |

## Technologies

- Vanilla HTML, CSS, JavaScript (front end)
- Python 3 standard-library HTTP server (local API)
- `google-play-scraper` (Google Play search-result retrieval)
- Apple public iTunes Search API (Apple search-result retrieval)
- Local storage and CSV (no database)

## Disclaimer

This is an independent utility, not affiliated with Apple or Google. Search results may be incomplete or vary by region and other conditions. Use detected positions as diagnostic indicators unless separately verified against the intended organic storefront search surface.
