Selene ASO rank track - Local Dashboard (Google Play Diagnostics Update)

Run on Windows:
1. Extract ALL files from the ZIP into one folder.
2. Double click start_windows.bat.
3. Open http://127.0.0.1:8765/selene-aso-rank-track.html
4. In Detected Positions mode, click Check Search Results.
5. Hover over Not detected to see the number of returned results and app availability.

Not detected: exact app ID absent from the results returned by the scraper.
It does NOT prove that the app is unranked. The scraper may return fewer than
100 results or a different sequence from the public Google Play storefront.

Numeric results are provisional search-list positions, NOT certified organic rankings.
CSV keeps source and verification metadata. No subscription/cloud/backend required.

To preserve existing tracked keywords, use the same browser and localhost address.
You can export your existing history before replacing the app.

IMPORTANT: Close old ASO server before running this launcher. Open http://127.0.0.1:8765/selene-aso-rank-track.html?v=2.
