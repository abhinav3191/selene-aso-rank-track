"""Selene ASO rank track local-only server. Search listing positions are PROVISIONAL, not certified organic ranks."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, urlencode
from urllib.request import Request, urlopen
import json, os, re, time

ROOT = os.path.dirname(os.path.abspath(__file__))


def fetch_apple(keyword, app_id, country, language):
    params = urlencode({'term': keyword, 'entity': 'software', 'media': 'software', 'country': country.lower(), 'limit': 200})
    req = Request('https://itunes.apple.com/search?' + params, headers={'User-Agent': 'Selene-ASO/1.0', 'Accept': 'application/json'})
    with urlopen(req, timeout=20) as resp:
        obj = json.load(resp)
    results = obj.get('results', [])
    ids = [str(item.get('trackId', '')) for item in results]
    pos = ids.index(app_id) + 1 if app_id in ids else None
    return {'position': pos, 'results_scanned': len(ids), 'source': 'Apple iTunes Search API order',
            'verified_organic': False, 'status': 'candidate' if pos else 'not_found',
            'note': 'Apple Search API relevance order does not establish the actual organic storefront position. Never treat as verified organic rank.'}


def fetch_google(keyword, app_id, country, language):
    """Return only positions found in the retrieved list. Absence is not proof of no rank."""
    try:
        from google_play_scraper import search, app
    except ImportError:
        return {'status': 'unavailable', 'position': None, 'source': 'Google Play search scraper',
                'verified_organic': False, 'results_scanned': 0,
                'note': 'Dependency missing. Install with: python -m pip install -r requirements.txt'}

    # This library can return fewer than n_hits. Do not claim to have checked 100
    # results unless 100 were actually returned.
    results = search(keyword, lang=language.lower(), country=country.lower(), n_hits=100)
    ids = [str(item.get('appId', '')) for item in results]
    pos = ids.index(app_id) + 1 if app_id in ids else None
    base = {'position': pos, 'results_scanned': len(ids),
            'requested_results': 100, 'source': 'Google Play scraped search listing order',
            'verified_organic': False}
    if pos is not None:
        return {**base, 'status': 'candidate',
                'note': f'Matched exact package ID at position {pos} among {len(ids)} returned results. Provisional search-list order, not independently verified storefront organic rank.'}

    # Identify removal/region errors separately. An app existing in the catalog
    # does not imply it appears in this search result list.
    try:
        details = app(app_id, lang=language.lower(), country=country.lower())
        title = str(details.get('title', app_id))[:100]
        return {**base, 'status': 'not_in_results', 'app_available': True,
                'note': f'App \"{title}\" exists in Google Play for {country}, but was not returned among {len(ids)} search results (requested up to 100). This does NOT establish an unranked position; Google Play may return a limited or different list.'}
    except Exception as e:
        return {**base, 'status': 'not_in_results', 'app_available': None,
                'note': f'Exact package ID missing from {len(ids)} returned search results (requested up to 100). Catalog lookup also failed ({type(e).__name__}); rank remains unknown.'}


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def end_headers(self):
        if self.path.split('?')[0].endswith(('.html','.js','.css')):
            self.send_header('Cache-Control', 'no-store, max-age=0')
        super().end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/api/health':
            return self.send_json({'ok': True, 'mode': 'local', 'ranking_verification': 'manual_confirmation_required'})
        return super().do_GET()

    def do_POST(self):
        if urlparse(self.path).path != '/api/check':
            return self.send_json({'error': 'Not found'}, 404)
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if size < 1 or size > 200000:
                return self.send_json({'error': 'Invalid request size'}, 400)
            payload = json.loads(self.rfile.read(size))
            rows = payload.get('keywords', [])
            if not isinstance(rows, list) or len(rows) > 100:
                return self.send_json({'error': 'Provide up to 100 keywords per batch'}, 400)
            output = []
            for row in rows:
                k = str(row.get('keyword','')).strip()[:120]
                app_id = str(row.get('app_id','')).strip()
                store = str(row.get('store',''))
                country = str(row.get('country','US')).upper()
                language = str(row.get('language','en')).lower()
                record_key = str(row.get('key',''))
                if not k or not re.fullmatch(r'[A-Z]{2}', country) or not re.fullmatch(r'[a-z]{2}', language) or not app_id or len(app_id)>150:
                    result = {'position': None, 'status': 'unavailable', 'note': 'Invalid keyword, app ID, language, or country'}
                else:
                    try:
                        if store == 'Apple App Store' and re.fullmatch(r'\d+', app_id):
                            result = fetch_apple(k,app_id,country,language)
                        elif store == 'Google Play' and re.fullmatch(r'[a-zA-Z0-9_.]+', app_id):
                            result = fetch_google(k,app_id,country,language)
                        else:
                            result = {'position': None, 'status':'unavailable','note':'Invalid store or app ID'}
                    except Exception as e:
                        result = {'position': None, 'status': 'unavailable', 'note': 'Store request failed: ' + str(e)[:160]}
                output.append({'key': record_key, 'keyword': k, 'store':store, 'country':country, **result})
                if store == 'Apple App Store' and len(rows)>1:
                    time.sleep(3.1) # avoid abusing public API
            return self.send_json({'results':output})
        except Exception as e:
            return self.send_json({'error': 'Processing failed: ' + str(e)[:160]}, 400)

    def send_json(self, data, code=200):
        out = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(out)))
        self.end_headers()
        self.wfile.write(out)


if __name__ == '__main__':
    print('Selene ASO rank track local web dashboard: http://127.0.0.1:8765/selene-aso-rank-track.html', flush=True)
    ThreadingHTTPServer(('127.0.0.1', 8765), Handler).serve_forever()
