@echo off
setlocal
cd /d "%~dp0"
if not exist "requirements.txt" (
  echo ERROR: Please extract the entire ZIP first.
  pause
  exit /b 1
)
if not exist "selene-aso-rank-track.html" (
  echo ERROR: Selene HTML file is missing. Extract the entire ZIP.
  pause
  exit /b 1
)
REM Stop here if a previous server is already using the port.
python -c "import socket,sys; s=socket.socket(); s.settimeout(1); r=s.connect_ex(('127.0.0.1',8765)); s.close(); sys.exit(1 if r==0 else 0)"
if errorlevel 1 (
  echo.
  echo ERROR: An older ASO server is still running on port 8765.
  echo Close the previous Command Prompt window and run this file again.
  echo You can also press Ctrl+C in the old server window to stop it.
  pause
  exit /b 1
)
python -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo ERROR: Dependencies could not be installed.
  pause
  exit /b 1
)
start "" "http://127.0.0.1:8765/selene-aso-rank-track.html?v=2"
python "%~dp0rank_server.py"
pause
